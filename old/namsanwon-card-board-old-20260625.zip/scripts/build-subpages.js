const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const pageDir = path.join(root, "page");
const mainHtml = fs.readFileSync(path.join(pageDir, "namsanwon.html"), "utf8");
const header = mainHtml.match(/<header class="globalNav"[\s\S]*?<\/header>/)[0];

const groups = [
  {
    key: "about",
    title: "남산원소개",
    description: "아이들이 안전한 일상 속에서 건강하게 성장할 수 있도록 남산원의 이야기를 전합니다.",
    items: [
      ["about.html", "인사말"],
      ["history.html", "연혁"],
      ["status.html", "현황"],
      ["facilities.html", "시설안내"],
      ["location.html", "오시는 길"],
      ["history-photo.html", "남산원역사사진"],
    ],
  },
  {
    key: "business",
    title: "사업소개",
    description: "생활, 교육, 자립, 행정 지원을 통해 아이들의 오늘과 내일을 함께 돌봅니다.",
    items: [
      ["admin-support.html", "행정지원팀"],
      ["self-reliance.html", "자립지원팀"],
      ["education.html", "교육지원팀"],
      ["care.html", "보육지원팀"],
    ],
  },
  {
    key: "support",
    title: "후원/자원봉사",
    description: "따뜻한 후원과 자원봉사로 아이들의 배움과 성장을 함께 이어갑니다.",
    items: [
      ["support-cms.html", "후원신청 안내"],
      ["volunteer.html", "자원봉사신청 안내"],
    ],
  },
  {
    key: "children",
    title: "아동생활",
    description: "남산원 아이들의 일상과 학교생활 소식을 전합니다.",
    items: [
      ["child-life.html", "아동생활 소식"],
      ["school-life.html", "학교생활 소식"],
    ],
  },
  {
    key: "community",
    title: "커뮤니티",
    description: "공지사항과 갤러리, 소식지를 통해 남산원의 새로운 소식을 확인하실 수 있습니다.",
    items: [
      ["notice.html", "공지사항"],
      ["free-board.html", "자유게시판"],
      ["foreign-sponsored.html", "Foreign Sponsored"],
      ["newsletter.html", "소식지"],
      ["gallery.html", "갤러리"],
    ],
  },
  {
    key: "member",
    title: "회원",
    description: "남산원 홈페이지 회원 서비스를 이용하실 수 있습니다.",
    items: [
      ["login.html", "로그인"],
      ["join.html", "회원가입"],
    ],
  },
];

const aliases = new Map([
  ["support.html", "support-cms.html"],
  ["international-sponsorship.html", "support-cms.html"],
  ["children.html", "child-life.html"],
  ["community.html", "notice.html"],
  ["programs.html", "admin-support.html"],
  ["notice-detail.html", "notice.html"],
  ["gallery-detail.html", "gallery.html"],
  ["qna.html", "notice.html"],
  ["budget.html", "notice.html"],
]);

const pageMap = new Map();
for (const group of groups) {
  for (const [file, title] of group.items) {
    pageMap.set(file, { group, activeFile: file, title });
  }
}
for (const [file, target] of aliases) {
  const targetPage = pageMap.get(target);
  if (targetPage) {
    const customTitles = {
      "support.html": "후원신청 안내",
      "international-sponsorship.html": "International Sponsorship",
      "children.html": "아동생활",
      "community.html": "커뮤니티",
      "programs.html": "사업소개",
      "notice-detail.html": "게시판 상세",
      "gallery-detail.html": "갤러리 상세",
      "qna.html": "질문과 답변",
      "budget.html": "예산게시판",
    };
    pageMap.set(file, { ...targetPage, title: customTitles[file] });
  }
}

pageMap.set("sitemap.html", {
  group: {
    title: "사이트맵",
    description: "남산원 홈페이지의 전체 메뉴를 한눈에 확인하실 수 있습니다.",
    items: [["sitemap.html", "사이트맵"]],
  },
  activeFile: "sitemap.html",
  title: "사이트맵",
});

function localNav(group, activeFile) {
  return `
  <nav class="localNav" aria-label="${group.title} 하위 메뉴">
    <div class="localNavInner">
${group.items
  .map(([file, title]) => {
    const active = file === activeFile;
    return `      <a${active ? ' class="isActive" aria-current="page"' : ""} href="./${file}">${title}</a>`;
  })
  .join("\n")}
    </div>
  </nav>`;
}

const noticeItems = [
  { category: "공지", title: "개인정보로 인하여 아동의 사진, 영상은 모자이크 또는 게시되지 않습니다.", date: "2024.01.02", views: "1,240", hasImage: true },
  { category: "", title: "[채용중] 26.6.8~6.23 생활지도원 채용공고", date: "2024.01.02", views: "1,240", hasImage: true },
  { category: "예산", title: "2024년 남산원 1차 추가경정 예산 공고", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "결산", title: "2023년 남산원 세입·세출 결산 보고", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "법인", title: "사회복지법인 남산원 이사회 회의록 공개", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "남산원 아이들의 여름 캠프 후원 감사 인사", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "자원봉사 활동 확인서 발급 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "후원금 영수증 신청 방법 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "봄맞이 시설 환경정비 일정 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "남산원 홈페이지 이용 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "2024년 1분기 운영 소식 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "어린이날 행사 후원 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "생활관 방역 및 위생 점검 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "남산원 후원 물품 접수 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "아동 프로그램 운영 일정 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "겨울방학 체험활동 결과 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "시설 안전 점검 완료 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "후원자 감사 편지 발송 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "자원봉사 신규 오리엔테이션 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "남산원 소식지 발행 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "아이들 교육 프로그램 후원 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "상담 프로그램 운영 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "시설 방문 예약 안내", date: "2024.01.02", views: "1,240", hasImage: false },
  { category: "", title: "남산원 운영 일정 변경 안내", date: "2024.01.02", views: "1,240", hasImage: false },
];

function noticeContent() {
  return `    <div class="subPageHeader">
      <h2>공지사항</h2>
      <nav class="breadcrumb" aria-label="현재 위치">
        <a class="breadcrumbHome" href="./namsanwon.html" aria-label="홈"></a>
        <span>커뮤니티</span>
        <strong>공지사항</strong>
      </nav>
    </div>
    <div class="noticeToolbar">
      <div class="noticeFilterGroup" data-notice-filters aria-label="공지사항 분류">
        <button class="isActive" type="button" data-notice-filter="공지사항" aria-pressed="true">공지사항</button>
        <button type="button" data-notice-filter="예산" aria-pressed="false">예산</button>
        <button type="button" data-notice-filter="결산" aria-pressed="false">결산</button>
        <button type="button" data-notice-filter="법인" aria-pressed="false">법인</button>
      </div>
      <form class="noticeSearch" data-notice-search>
        <label class="blind" for="noticeSearchCategory">검색 분류</label>
        <select id="noticeSearchCategory" data-notice-search-category>
          <option value="전체">전체</option>
          <option value="공지사항">공지사항</option>
          <option value="예산">예산</option>
          <option value="결산">결산</option>
          <option value="법인">법인</option>
        </select>
        <label class="blind" for="noticeSearchKeyword">검색어</label>
        <input id="noticeSearchKeyword" type="search" data-notice-search-keyword placeholder="검색어를 입력하세요">
        <button type="submit" aria-label="검색"></button>
      </form>
    </div>
    <div class="noticeCardGrid" aria-label="공지사항 게시물 목록">
${noticeItems
  .map((item) => {
    const cardCategory = item.category && item.category !== "공지" ? item.category : "공지사항";
    const visibleLabel = item.category === "공지" ? `          <span class="noticeCardLabel">공지</span>\n` : "";
    const hiddenCategory = item.category && item.category !== "공지" ? `          <span class="blind">분류: ${item.category}</span>\n` : "";
    const imageIcon = item.hasImage ? `            <span class="noticeImageIcon" aria-label="이미지 있음"></span>\n` : "";
    return `      <article class="noticeCard${item.category === "공지" ? " hasNoticeLabel" : ""}" data-category="${cardCategory}" data-title="${item.title}">
        <a href="./notice-detail.html">
${visibleLabel}${hiddenCategory}          <span class="noticeCardTitle">
            <strong>${item.title}</strong>
${imageIcon}          </span>
          <span class="noticeCardMeta">
            <time datetime="${item.date.replace(/\./g, "-")}">${item.date}</time>
            <span class="noticeViewCount"><span class="blind">조회수</span>${item.views}</span>
          </span>
        </a>
      </article>`;
  })
  .join("\n")}
    </div>
    <nav class="noticePagination" aria-label="공지사항 페이지">
      <a class="noticePageButton isDisabled" href="#" aria-disabled="true" aria-label="이전 페이지">‹</a>
      <a class="noticePageButton isActive" href="#" aria-current="page">1</a>
      <a class="noticePageButton" href="#">2</a>
      <a class="noticePageButton" href="#">3</a>
      <a class="noticePageButton" href="#">4</a>
      <a class="noticePageButton" href="#">5</a>
      <a class="noticePageButton" href="#" aria-label="다음 페이지">›</a>
    </nav>
    <div class="noticePullHint" data-notice-pull-hint hidden aria-hidden="true">
      <span></span>
      <span></span>
    </div>
    <div class="noticeMobileLoader" data-notice-mobile-loader hidden aria-live="polite">
      <span></span>
      <span class="blind">게시물 불러오는 중</span>
    </div>`;
}

function defaultSubContent(page) {
  return `    <h2>${page.title}</h2>
    <p>${page.title} 페이지입니다. 세부 콘텐츠는 운영 자료에 맞춰 확장할 수 있습니다.</p>
    <a class="subPageLink" href="./namsanwon.html">메인으로 돌아가기</a>`;
}

function mainContent(page, file) {
  if (file === "notice.html") {
    return noticeContent();
  }

  return defaultSubContent(page);
}

function subpageContent(page, file) {
  return `<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${page.title} | 남산원</title>
  <link rel="stylesheet" href="../css/reset.css">
  <link rel="stylesheet" href="../css/fonts.css">
  <link rel="stylesheet" href="../css/root.css">
  <link rel="stylesheet" href="../css/namsanwon.css">
</head>
<body data-current-section="${page.group.key}" data-current-page="${page.activeFile}">
  <a class="skipLink" href="#main">본문 바로가기</a>

${header}

  <section class="subVisual" aria-labelledby="subVisualTitle">
    <div class="subVisualInner">
      <h1 id="subVisualTitle">${page.group.title}</h1>
      <p>${page.group.description}</p>
    </div>
  </section>

${localNav(page.group, page.activeFile)}

  <main class="subPage" id="main">
${mainContent(page, file)}
  </main>

  <script src="../js/namsanwon.js"></script>
</body>
</html>
`;
}

for (const file of fs.readdirSync(pageDir)) {
  if (!file.endsWith(".html") || file === "namsanwon.html") continue;
  const page = pageMap.get(file);
  if (!page) continue;
  fs.writeFileSync(path.join(pageDir, file), subpageContent(page, file));
}
